# Community-Eats CIS 376 Final Project
The project runs on React and is hosted on Firebase.

## How to run it:

- Download the zip file or copy the GitHub link
- Open Visual Studio Code
- Open the zip file or click "Clone a respository" and paste the GitHub link
- Open a new terminal in Visual Studio Code
- Enter these following commands:
  - cd my-app
  - npm install
  - npm install firebase
  - npm install slick-carousel react-slick
  - npm start

The project should open in a new browser window, from there, enjoy our website!
Johns test contributer commit